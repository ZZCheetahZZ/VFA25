local unitPayloads = {
	["name"] = "FA-18C_hornet",
	["payloads"] = {
		[1] = {
			["name"] = "[J-84 2]: 2 GBU-31 | TGP | 3 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[4] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[5] = {
					["CLSID"] = "{GBU-31}",
					["num"] = 2,
				},
				[6] = {
					["CLSID"] = "{GBU-31}",
					["num"] = 8,
				},
				[7] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
				[9] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
			},
			["tasks"] = {
				[1] = 32,
			},
		},
		[2] = {
			["name"] = "AIM-9X*2, FUEL*1 (Light)",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
			},
			["tasks"] = {
				[1] = 11,
			},
		},
		[3] = {
			["name"] = "[A2A 7]: 4 AIM-7M | 2 AIM-9M | 3 Tanks ",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{6CEB49FC-DED8-4DED-B053-E1F033FF72D3}",
					["num"] = 9,
				},
				[2] = {
					["CLSID"] = "{6CEB49FC-DED8-4DED-B053-E1F033FF72D3}",
					["num"] = 1,
				},
				[3] = {
					["CLSID"] = "{8D399DDA-FF81-4F14-904D-099B34FE7918}",
					["num"] = 4,
				},
				[4] = {
					["CLSID"] = "{8D399DDA-FF81-4F14-904D-099B34FE7918}",
					["num"] = 6,
				},
				[5] = {
					["CLSID"] = "{LAU-115 - AIM-7M}",
					["num"] = 8,
				},
				[6] = {
					["CLSID"] = "{LAU-115 - AIM-7M}",
					["num"] = 2,
				},
				[7] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[8] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[9] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
			},
			["tasks"] = {
				[1] = 11,
			},
		},
		[4] = {
			["name"] = "[Anti Ship 3]: 2 AGM-84 | TGP | 3 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{AGM_84D}",
					["num"] = 8,
				},
				[2] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
				[4] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[5] = {
					["CLSID"] = "{AGM_84D}",
					["num"] = 2,
				},
				[6] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[7] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[8] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[9] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
			},
			["tasks"] = {
				[1] = 30,
			},
		},
		[5] = {
			["name"] = "[DU 5]:  3 GBU-12 ",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[4] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[5] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
				[6] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
				[7] = {
					["CLSID"] = "{DB769D48-67D7-42ED-A2BE-108D566C8B1E}",
					["num"] = 8,
				},
				[8] = {
					["CLSID"] = "{DB769D48-67D7-42ED-A2BE-108D566C8B1E}",
					["num"] = 3,
				},
				[9] = {
					["CLSID"] = "{DB769D48-67D7-42ED-A2BE-108D566C8B1E}",
					["num"] = 2,
				},
			},
			["tasks"] = {
				[1] = 29,
			},
		},
		[6] = {
			["name"] = "[A2A 5]: 8 AIM-120C | 2 AIM-9X | 1 Tank",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[3] = {
					["CLSID"] = "{LAU-115 - AIM-120C}",
					["num"] = 8,
				},
				[4] = {
					["CLSID"] = "{LAU-115 - AIM-120C}",
					["num"] = 2,
				},
				[5] = {
					["CLSID"] = "LAU-115_2*LAU-127_AIM-120C",
					["num"] = 3,
				},
				[6] = {
					["CLSID"] = "LAU-115_2*LAU-127_AIM-120C",
					["num"] = 7,
				},
				[7] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
				[8] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 4,
				},
				[9] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
			},
			["tasks"] = {
				[1] = 11,
			},
		},
		[7] = {
			["name"] = "[A2A 1]: 4 AIM-120C | 2 AIM-9X | 2 Tanks",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[3] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 4,
				},
				[4] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[5] = {
					["CLSID"] = "{LAU-115 - AIM-120C}",
					["num"] = 8,
				},
				[6] = {
					["CLSID"] = "{LAU-115 - AIM-120C}",
					["num"] = 2,
				},
				[7] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[8] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
			},
			["tasks"] = {
				[1] = 11,
			},
		},
		[8] = {
			["name"] = "[SLAM 1]: 2 AGM-84E | TGP | DL | 2 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{AF42E6DF-9A60-46D8-A9A0-1708B241AADB}",
					["num"] = 8,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[4] = {
					["CLSID"] = "{AF42E6DF-9A60-46D8-A9A0-1708B241AADB}",
					["num"] = 2,
				},
				[5] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[6] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[7] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
				[9] = {
					["CLSID"] = "{AWW-13}",
					["num"] = 5,
				},
			},
			["tasks"] = {
				[1] = 29,
			},
		},
		[9] = {
			["name"] = "[GBU-12 2]: 2 GBU-12 | TGP | 3 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[4] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[5] = {
					["CLSID"] = "{DB769D48-67D7-42ED-A2BE-108D566C8B1E}",
					["num"] = 2,
				},
				[6] = {
					["CLSID"] = "{DB769D48-67D7-42ED-A2BE-108D566C8B1E}",
					["num"] = 8,
				},
				[7] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
				[9] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
			},
			["tasks"] = {
				[1] = 32,
			},
		},
		[10] = {
			["name"] = "[Anti Ship 1]: 4 AGM-84 | TGP | 1 Tank | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{AGM_84D}",
					["num"] = 8,
				},
				[2] = {
					["CLSID"] = "{AGM_84D}",
					["num"] = 7,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
				[4] = {
					["CLSID"] = "{AGM_84D}",
					["num"] = 3,
				},
				[5] = {
					["CLSID"] = "{AGM_84D}",
					["num"] = 2,
				},
				[6] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[7] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[8] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[9] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
			},
			["tasks"] = {
				[1] = 30,
			},
		},
		[11] = {
			["name"] = "[MK-83 1]: 2 MK-83 | 2 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{6CEB49FC-DED8-4DED-B053-E1F033FF72D3}",
					["num"] = 1,
				},
				[2] = {
					["CLSID"] = "{6CEB49FC-DED8-4DED-B053-E1F033FF72D3}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[4] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[5] = {
					["CLSID"] = "{7A44FF09-527C-4B7E-B42B-3F111CFE50FB}",
					["num"] = 2,
				},
				[6] = {
					["CLSID"] = "{7A44FF09-527C-4B7E-B42B-3F111CFE50FB}",
					["num"] = 8,
				},
				[7] = {
					["CLSID"] = "{C8E06185-7CD6-4C90-959F-044679E90751}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{C8E06185-7CD6-4C90-959F-044679E90751}",
					["num"] = 4,
				},
			},
			["tasks"] = {
				[1] = 32,
			},
		},
		[12] = {
			["name"] = "[SEAD 5]: 2 AGM-88 | 3 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{B06DD79A-F21E-4EB9-BD9D-AB3844618C93}",
					["num"] = 8,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[4] = {
					["CLSID"] = "{B06DD79A-F21E-4EB9-BD9D-AB3844618C93}",
					["num"] = 2,
				},
				[5] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[6] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[7] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 4,
				},
				[9] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
			},
			["tasks"] = {
				[1] = 29,
			},
		},
		[13] = {
			["name"] = "[A2A 4]: 6 AIM-120C | 2 AIM-9X | 3 Tanks",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[3] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 4,
				},
				[4] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[5] = {
					["CLSID"] = "LAU-115_2*LAU-127_AIM-120C",
					["num"] = 8,
				},
				[6] = {
					["CLSID"] = "LAU-115_2*LAU-127_AIM-120C",
					["num"] = 2,
				},
				[7] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[8] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[9] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
			},
			["tasks"] = {
				[1] = 11,
			},
		},
		[14] = {
			["name"] = "[J-82 3]: 4 GBU-38 | TGP | 2 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[4] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[5] = {
					["CLSID"] = "{BRU55_2*GBU-38}",
					["num"] = 2,
				},
				[6] = {
					["CLSID"] = "{BRU55_2*GBU-38}",
					["num"] = 8,
				},
				[7] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
			},
			["tasks"] = {
				[1] = 32,
			},
		},
		[15] = {
			["name"] = "[A2A 9]: 4 AIM-7MH | 2 AIM-9M | 3 Tanks ",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{6CEB49FC-DED8-4DED-B053-E1F033FF72D3}",
					["num"] = 9,
				},
				[2] = {
					["CLSID"] = "{6CEB49FC-DED8-4DED-B053-E1F033FF72D3}",
					["num"] = 1,
				},
				[3] = {
					["CLSID"] = "{AIM-7H}",
					["num"] = 4,
				},
				[4] = {
					["CLSID"] = "{AIM-7H}",
					["num"] = 6,
				},
				[5] = {
					["CLSID"] = "{LAU-115 - AIM-7H}",
					["num"] = 8,
				},
				[6] = {
					["CLSID"] = "{LAU-115 - AIM-7H}",
					["num"] = 2,
				},
				[7] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[8] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[9] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
			},
			["tasks"] = {
				[1] = 11,
			},
		},
		[16] = {
			["name"] = "[GBU-16 2]: 2 GBU-16 | TGP | 3 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[4] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[5] = {
					["CLSID"] = "{0D33DDAE-524F-4A4E-B5B8-621754FE3ADE}",
					["num"] = 2,
				},
				[6] = {
					["CLSID"] = "{0D33DDAE-524F-4A4E-B5B8-621754FE3ADE}",
					["num"] = 8,
				},
				[7] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
				[9] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
			},
			["tasks"] = {
				[1] = 32,
			},
		},
		[17] = {
			["name"] = "[VFA-25 AA Training]: Team B",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
				[2] = {
					["CLSID"] = "CATM-9M",
					["num"] = 1,
				},
				[3] = {
					["CLSID"] = "{AIS_ASQ_T50}",
					["num"] = 9,
				},
			},
			["tasks"] = {
				[1] = 11,
			},
		},
		[18] = {
			["name"] = "[VFA-25 AA Training]: Team A",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
				[2] = {
					["CLSID"] = "CATM-9M",
					["num"] = 1,
				},
			},
			["tasks"] = {
				[1] = 11,
			},
		},
		[19] = {
			["name"] = "[DU 6]:  1 GBU-12 | 2 GBU-38",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[4] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[5] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
				[6] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
				[7] = {
					["CLSID"] = "{DB769D48-67D7-42ED-A2BE-108D566C8B1E}",
					["num"] = 8,
				},
				[8] = {
					["CLSID"] = "{GBU-38}",
					["num"] = 3,
				},
				[9] = {
					["CLSID"] = "{GBU-38}",
					["num"] = 2,
				},
			},
			["tasks"] = {
				[1] = 29,
			},
		},
		[20] = {
			["name"] = "[J-82 2]: 2 GBU-38 | TGP | 3 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[4] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[5] = {
					["CLSID"] = "{GBU-38}",
					["num"] = 2,
				},
				[6] = {
					["CLSID"] = "{GBU-38}",
					["num"] = 8,
				},
				[7] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
				[9] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
			},
			["tasks"] = {
				[1] = 32,
			},
		},
		[21] = {
			["name"] = "[DU 2]: AGM 65E | 2 GBU-12 | GBU-38",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[4] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[5] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
				[6] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
				[7] = {
					["CLSID"] = "{F16A4DE0-116C-4A71-97F0-2CF85B0313EC}",
					["num"] = 8,
				},
				[8] = {
					["CLSID"] = "{BRU33_2X_GBU-12}",
					["num"] = 3,
				},
				[9] = {
					["CLSID"] = "{GBU-38}",
					["num"] = 2,
				},
			},
			["tasks"] = {
				[1] = 29,
			},
		},
		[22] = {
			["name"] = "[MK-84 2]: 2 MK-84 | 3 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{6CEB49FC-DED8-4DED-B053-E1F033FF72D3}",
					["num"] = 1,
				},
				[2] = {
					["CLSID"] = "{6CEB49FC-DED8-4DED-B053-E1F033FF72D3}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[4] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[5] = {
					["CLSID"] = "{AB8B8299-F1CC-4359-89B5-2172E0CF4A5A}",
					["num"] = 2,
				},
				[6] = {
					["CLSID"] = "{AB8B8299-F1CC-4359-89B5-2172E0CF4A5A}",
					["num"] = 8,
				},
				[7] = {
					["CLSID"] = "{C8E06185-7CD6-4C90-959F-044679E90751}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{C8E06185-7CD6-4C90-959F-044679E90751}",
					["num"] = 4,
				},
				[9] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
			},
			["tasks"] = {
				[1] = 32,
			},
		},
		[23] = {
			["name"] = "Clean (No pylons)",
			["pylons"] = {
				[1] = {
					["CLSID"] = "<CLEAN>",
					["num"] = 8,
				},
				[2] = {
					["CLSID"] = "<CLEAN>",
					["num"] = 7,
				},
				[3] = {
					["CLSID"] = "<CLEAN>",
					["num"] = 5,
				},
				[4] = {
					["CLSID"] = "<CLEAN>",
					["num"] = 3,
				},
				[5] = {
					["CLSID"] = "<CLEAN>",
					["num"] = 2,
				},
			},
			["tasks"] = {
				[1] = 11,
			},
		},
		[24] = {
			["name"] = "[DU 3]: AGM 65F | GBU-12 | GBU-38",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[4] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[5] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
				[6] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
				[7] = {
					["CLSID"] = "LAU_117_AGM_65F",
					["num"] = 8,
				},
				[8] = {
					["CLSID"] = "{DB769D48-67D7-42ED-A2BE-108D566C8B1E}",
					["num"] = 3,
				},
				[9] = {
					["CLSID"] = "{GBU-38}",
					["num"] = 2,
				},
			},
			["tasks"] = {
				[1] = 29,
			},
		},
		[25] = {
			["name"] = "[GBU-12 4]: 4 GBU-12 | TGP | 3 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[4] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[5] = {
					["CLSID"] = "{BRU33_2X_GBU-12}",
					["num"] = 2,
				},
				[6] = {
					["CLSID"] = "{BRU33_2X_GBU-12}",
					["num"] = 8,
				},
				[7] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
				[9] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
			},
			["tasks"] = {
				[1] = 32,
			},
		},
		[26] = {
			["name"] = "[DU 4]: AGM 65F | 2 GBU-12 | GBU-38",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[4] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[5] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
				[6] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
				[7] = {
					["CLSID"] = "LAU_117_AGM_65F",
					["num"] = 8,
				},
				[8] = {
					["CLSID"] = "{BRU33_2X_GBU-12}",
					["num"] = 3,
				},
				[9] = {
					["CLSID"] = "{GBU-38}",
					["num"] = 2,
				},
			},
			["tasks"] = {
				[1] = 29,
			},
		},
		[27] = {
			["name"] = "[JSOW C 2]: 2 AGM-145C | TGP | 3 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{9BCC2A2B-5708-4860-B1F1-053A18442067}",
					["num"] = 8,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[4] = {
					["CLSID"] = "{9BCC2A2B-5708-4860-B1F1-053A18442067}",
					["num"] = 2,
				},
				[5] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[6] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[7] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
				[9] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
			},
			["tasks"] = {
				[1] = 29,
			},
		},
		[28] = {
			["name"] = "[JSOW A 2]: 2 AGM-145A | TGP | 3 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{AGM-154A}",
					["num"] = 8,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[4] = {
					["CLSID"] = "{AGM-154A}",
					["num"] = 2,
				},
				[5] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[6] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[7] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
				[9] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
			},
			["tasks"] = {
				[1] = 29,
			},
		},
		[29] = {
			["name"] = "[GBU-10 1]: 2 GBU-10 | TGP | 2 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[4] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[5] = {
					["CLSID"] = "{51F9AAE5-964F-4D21-83FB-502E3BFE5F8A}",
					["num"] = 2,
				},
				[6] = {
					["CLSID"] = "{51F9AAE5-964F-4D21-83FB-502E3BFE5F8A}",
					["num"] = 8,
				},
				[7] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
			},
			["tasks"] = {
				[1] = 32,
			},
		},
		[30] = {
			["name"] = "[MK-83 2]: 2 MK-83 | 3 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{6CEB49FC-DED8-4DED-B053-E1F033FF72D3}",
					["num"] = 1,
				},
				[2] = {
					["CLSID"] = "{6CEB49FC-DED8-4DED-B053-E1F033FF72D3}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[4] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[5] = {
					["CLSID"] = "{7A44FF09-527C-4B7E-B42B-3F111CFE50FB}",
					["num"] = 2,
				},
				[6] = {
					["CLSID"] = "{7A44FF09-527C-4B7E-B42B-3F111CFE50FB}",
					["num"] = 8,
				},
				[7] = {
					["CLSID"] = "{C8E06185-7CD6-4C90-959F-044679E90751}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{C8E06185-7CD6-4C90-959F-044679E90751}",
					["num"] = 4,
				},
				[9] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
			},
			["tasks"] = {
				[1] = 32,
			},
		},
		[31] = {
			["name"] = "[JSOW C 1]: 2 AGM-145C | TGP | 2 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{9BCC2A2B-5708-4860-B1F1-053A18442067}",
					["num"] = 8,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[4] = {
					["CLSID"] = "{9BCC2A2B-5708-4860-B1F1-053A18442067}",
					["num"] = 2,
				},
				[5] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[6] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[7] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
			},
			["tasks"] = {
				[1] = 29,
			},
		},
		[32] = {
			["name"] = "[A2A 3]: 4 AIM-120C | 2 AIM-9X | 3 Tanks",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[3] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 4,
				},
				[4] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[5] = {
					["CLSID"] = "{LAU-115 - AIM-120C}",
					["num"] = 8,
				},
				[6] = {
					["CLSID"] = "{LAU-115 - AIM-120C}",
					["num"] = 2,
				},
				[7] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[8] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[9] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
			},
			["tasks"] = {
				[1] = 11,
			},
		},
		[33] = {
			["name"] = "[J-82 1]: 2 GBU-38 | TGP | 2 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[4] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[5] = {
					["CLSID"] = "{GBU-38}",
					["num"] = 2,
				},
				[6] = {
					["CLSID"] = "{GBU-38}",
					["num"] = 8,
				},
				[7] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
			},
			["tasks"] = {
				[1] = 32,
			},
		},
		[34] = {
			["name"] = "[GBU-16 1]: 2 GBU-16 | TGP | 2 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[4] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[5] = {
					["CLSID"] = "{0D33DDAE-524F-4A4E-B5B8-621754FE3ADE}",
					["num"] = 2,
				},
				[6] = {
					["CLSID"] = "{0D33DDAE-524F-4A4E-B5B8-621754FE3ADE}",
					["num"] = 8,
				},
				[7] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
			},
			["tasks"] = {
				[1] = 32,
			},
		},
		[35] = {
			["name"] = "[J-84 BB 1]: 2 GBU-31(V)3/B | TGP | 2 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[4] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[5] = {
					["CLSID"] = "{GBU-31V3B}",
					["num"] = 2,
				},
				[6] = {
					["CLSID"] = "{GBU-31V3B}",
					["num"] = 8,
				},
				[7] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
			},
			["tasks"] = {
				[1] = 32,
			},
		},
		[36] = {
			["name"] = "[DU 1]: AGM 65E | GBU-12 | GBU-38",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[4] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[5] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
				[6] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
				[7] = {
					["CLSID"] = "{F16A4DE0-116C-4A71-97F0-2CF85B0313EC}",
					["num"] = 8,
				},
				[8] = {
					["CLSID"] = "{DB769D48-67D7-42ED-A2BE-108D566C8B1E}",
					["num"] = 3,
				},
				[9] = {
					["CLSID"] = "{GBU-38}",
					["num"] = 2,
				},
			},
			["tasks"] = {
				[1] = 29,
			},
		},
		[37] = {
			["name"] = "[GBU-12 3]: 4 GBU-12 | TGP | 2 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[4] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[5] = {
					["CLSID"] = "{BRU33_2X_GBU-12}",
					["num"] = 2,
				},
				[6] = {
					["CLSID"] = "{BRU33_2X_GBU-12}",
					["num"] = 8,
				},
				[7] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
			},
			["tasks"] = {
				[1] = 32,
			},
		},
		[38] = {
			["name"] = "[SEAD 4]: 2 AGM-88 | TGP | 2 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{B06DD79A-F21E-4EB9-BD9D-AB3844618C93}",
					["num"] = 8,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[4] = {
					["CLSID"] = "{B06DD79A-F21E-4EB9-BD9D-AB3844618C93}",
					["num"] = 2,
				},
				[5] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[6] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[7] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
			},
			["tasks"] = {
				[1] = 29,
			},
		},
		[39] = {
			["name"] = "[SEAD 1]: 4 AGM-88 | 1 Tank | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{B06DD79A-F21E-4EB9-BD9D-AB3844618C93}",
					["num"] = 8,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[4] = {
					["CLSID"] = "{B06DD79A-F21E-4EB9-BD9D-AB3844618C93}",
					["num"] = 2,
				},
				[5] = {
					["CLSID"] = "{B06DD79A-F21E-4EB9-BD9D-AB3844618C93}",
					["num"] = 3,
				},
				[6] = {
					["CLSID"] = "{B06DD79A-F21E-4EB9-BD9D-AB3844618C93}",
					["num"] = 7,
				},
				[7] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 4,
				},
				[9] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
			},
			["tasks"] = {
				[1] = 29,
			},
		},
		[40] = {
			["name"] = "[Anti Ship 2]: 2 AGM-84 | TGP | 2 Tanks | AAM ",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{AGM_84D}",
					["num"] = 8,
				},
				[2] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[4] = {
					["CLSID"] = "{AGM_84D}",
					["num"] = 2,
				},
				[5] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[6] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[7] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
			},
			["tasks"] = {
				[1] = 30,
			},
		},
		[41] = {
			["name"] = "[GBU-10 2]: 2 GBU-10 | TGP | 3 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[4] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[5] = {
					["CLSID"] = "{51F9AAE5-964F-4D21-83FB-502E3BFE5F8A}",
					["num"] = 2,
				},
				[6] = {
					["CLSID"] = "{51F9AAE5-964F-4D21-83FB-502E3BFE5F8A}",
					["num"] = 8,
				},
				[7] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
				[9] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
			},
			["tasks"] = {
				[1] = 32,
			},
		},
		[42] = {
			["name"] = "[DU 0]: Template",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[4] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[5] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
				[6] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
			},
			["tasks"] = {
				[1] = 29,
			},
		},
		[43] = {
			["name"] = "[J-84 1]: 2 GBU-31 | TGP | 2 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[4] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[5] = {
					["CLSID"] = "{GBU-31}",
					["num"] = 2,
				},
				[6] = {
					["CLSID"] = "{GBU-31}",
					["num"] = 8,
				},
				[7] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
			},
			["tasks"] = {
				[1] = 32,
			},
		},
		[44] = {
			["name"] = "[VFA 25 AG Training]: 6 BDU-33 | TGP | 2 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "CATM-9M",
					["num"] = 9,
				},
				[2] = {
					["CLSID"] = "{AIS_ASQ_T50}",
					["num"] = 1,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[4] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[5] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
				[6] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
				[7] = {
					["CLSID"] = "{BRU41_6X_BDU-33}",
					["num"] = 3,
				},
			},
			["tasks"] = {
				[1] = 29,
			},
		},
		[45] = {
			["name"] = "[GBU-12 1]: 2 GBU-12 | TGP | 2 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[4] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[5] = {
					["CLSID"] = "{DB769D48-67D7-42ED-A2BE-108D566C8B1E}",
					["num"] = 2,
				},
				[6] = {
					["CLSID"] = "{DB769D48-67D7-42ED-A2BE-108D566C8B1E}",
					["num"] = 8,
				},
				[7] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
			},
			["tasks"] = {
				[1] = 32,
			},
		},
		[46] = {
			["name"] = "[SEAD 2]: 4 AGM-88 | TGP | 1 Tank | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{B06DD79A-F21E-4EB9-BD9D-AB3844618C93}",
					["num"] = 8,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[4] = {
					["CLSID"] = "{B06DD79A-F21E-4EB9-BD9D-AB3844618C93}",
					["num"] = 2,
				},
				[5] = {
					["CLSID"] = "{B06DD79A-F21E-4EB9-BD9D-AB3844618C93}",
					["num"] = 3,
				},
				[6] = {
					["CLSID"] = "{B06DD79A-F21E-4EB9-BD9D-AB3844618C93}",
					["num"] = 7,
				},
				[7] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
				[9] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
			},
			["tasks"] = {
				[1] = 29,
			},
		},
		[47] = {
			["name"] = "[A2A 8]: 4 AIM-7MH | 2 AIM-9M | 2 Tanks ",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{6CEB49FC-DED8-4DED-B053-E1F033FF72D3}",
					["num"] = 9,
				},
				[2] = {
					["CLSID"] = "{6CEB49FC-DED8-4DED-B053-E1F033FF72D3}",
					["num"] = 1,
				},
				[3] = {
					["CLSID"] = "{AIM-7H}",
					["num"] = 4,
				},
				[4] = {
					["CLSID"] = "{AIM-7H}",
					["num"] = 6,
				},
				[5] = {
					["CLSID"] = "{LAU-115 - AIM-7H}",
					["num"] = 8,
				},
				[6] = {
					["CLSID"] = "{LAU-115 - AIM-7H}",
					["num"] = 2,
				},
				[7] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[8] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
			},
			["tasks"] = {
				[1] = 11,
			},
		},
		[48] = {
			["name"] = "AIM-9M*2,AIM-120C*8, AIM-7M*2",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{6CEB49FC-DED8-4DED-B053-E1F033FF72D3}",
					["num"] = 9,
				},
				[2] = {
					["CLSID"] = "{6CEB49FC-DED8-4DED-B053-E1F033FF72D3}",
					["num"] = 1,
				},
				[3] = {
					["CLSID"] = "LAU-115_2*LAU-127_AIM-120C",
					["num"] = 2,
				},
				[4] = {
					["CLSID"] = "LAU-115_2*LAU-127_AIM-120C",
					["num"] = 3,
				},
				[5] = {
					["CLSID"] = "LAU-115_2*LAU-127_AIM-120C",
					["num"] = 8,
				},
				[6] = {
					["CLSID"] = "LAU-115_2*LAU-127_AIM-120C",
					["num"] = 7,
				},
				[7] = {
					["CLSID"] = "{8D399DDA-FF81-4F14-904D-099B34FE7918}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{8D399DDA-FF81-4F14-904D-099B34FE7918}",
					["num"] = 4,
				},
			},
			["tasks"] = {
				[1] = 11,
			},
		},
		[49] = {
			["name"] = "[A2A 6]: 4 AIM-7M | 2 AIM-9M | 2 Tanks ",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{6CEB49FC-DED8-4DED-B053-E1F033FF72D3}",
					["num"] = 9,
				},
				[2] = {
					["CLSID"] = "{6CEB49FC-DED8-4DED-B053-E1F033FF72D3}",
					["num"] = 1,
				},
				[3] = {
					["CLSID"] = "{8D399DDA-FF81-4F14-904D-099B34FE7918}",
					["num"] = 4,
				},
				[4] = {
					["CLSID"] = "{8D399DDA-FF81-4F14-904D-099B34FE7918}",
					["num"] = 6,
				},
				[5] = {
					["CLSID"] = "{LAU-115 - AIM-7M}",
					["num"] = 8,
				},
				[6] = {
					["CLSID"] = "{LAU-115 - AIM-7M}",
					["num"] = 2,
				},
				[7] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[8] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
			},
			["tasks"] = {
				[1] = 11,
			},
		},
		[50] = {
			["name"] = "[MK-84 1]: 2 MK-84 | 2 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{6CEB49FC-DED8-4DED-B053-E1F033FF72D3}",
					["num"] = 1,
				},
				[2] = {
					["CLSID"] = "{6CEB49FC-DED8-4DED-B053-E1F033FF72D3}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[4] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[5] = {
					["CLSID"] = "{AB8B8299-F1CC-4359-89B5-2172E0CF4A5A}",
					["num"] = 2,
				},
				[6] = {
					["CLSID"] = "{AB8B8299-F1CC-4359-89B5-2172E0CF4A5A}",
					["num"] = 8,
				},
				[7] = {
					["CLSID"] = "{C8E06185-7CD6-4C90-959F-044679E90751}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{C8E06185-7CD6-4C90-959F-044679E90751}",
					["num"] = 4,
				},
			},
			["tasks"] = {
				[1] = 32,
			},
		},
		[51] = {
			["name"] = "[SLAM 2 DU]: 2 AGM-84E | TGP | DL | 2 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{AF42E6DF-9A60-46D8-A9A0-1708B241AADB}",
					["num"] = 8,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[4] = {
					["CLSID"] = "{AF42E6DF-9A60-46D8-A9A0-1708B241AADB}",
					["num"] = 2,
				},
				[5] = {
					["CLSID"] = "{AWW-13}",
					["num"] = 3,
				},
				[6] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[7] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
				[9] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
			},
			["tasks"] = {
				[1] = 29,
			},
		},
		[52] = {
			["name"] = "[SEAD 3]: 2 AGM-88 | 2 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{B06DD79A-F21E-4EB9-BD9D-AB3844618C93}",
					["num"] = 8,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[4] = {
					["CLSID"] = "{B06DD79A-F21E-4EB9-BD9D-AB3844618C93}",
					["num"] = 2,
				},
				[5] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[6] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[7] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 4,
				},
			},
			["tasks"] = {
				[1] = 29,
			},
		},
		[53] = {
			["name"] = "[MK-82 2]: 4 MK-82 | 3 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{6CEB49FC-DED8-4DED-B053-E1F033FF72D3}",
					["num"] = 1,
				},
				[2] = {
					["CLSID"] = "{6CEB49FC-DED8-4DED-B053-E1F033FF72D3}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[4] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[5] = {
					["CLSID"] = "{BRU33_2X_MK-82}",
					["num"] = 2,
				},
				[6] = {
					["CLSID"] = "{BRU33_2X_MK-82}",
					["num"] = 8,
				},
				[7] = {
					["CLSID"] = "{C8E06185-7CD6-4C90-959F-044679E90751}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{C8E06185-7CD6-4C90-959F-044679E90751}",
					["num"] = 4,
				},
				[9] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
			},
			["tasks"] = {
				[1] = 32,
			},
		},
		[54] = {
			["name"] = "[A2A 2]: 6 AIM-120C | 2 AIM-9X | 2 Tanks",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[3] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 4,
				},
				[4] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[5] = {
					["CLSID"] = "LAU-115_2*LAU-127_AIM-120C",
					["num"] = 8,
				},
				[6] = {
					["CLSID"] = "LAU-115_2*LAU-127_AIM-120C",
					["num"] = 2,
				},
				[7] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[8] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
			},
			["tasks"] = {
				[1] = 11,
			},
		},
		[55] = {
			["name"] = "[JSOW A 1]: 2 AGM-145A | TGP | 2 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{AGM-154A}",
					["num"] = 8,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[4] = {
					["CLSID"] = "{AGM-154A}",
					["num"] = 2,
				},
				[5] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[6] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[7] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
			},
			["tasks"] = {
				[1] = 29,
			},
		},
		[56] = {
			["name"] = "[SEAD 6]: 2 AGM-88 | TGP | 3 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{B06DD79A-F21E-4EB9-BD9D-AB3844618C93}",
					["num"] = 8,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[4] = {
					["CLSID"] = "{B06DD79A-F21E-4EB9-BD9D-AB3844618C93}",
					["num"] = 2,
				},
				[5] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[6] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[7] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
				[9] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
			},
			["tasks"] = {
				[1] = 29,
			},
		},
		[57] = {
			["name"] = "[MK-83 4]: 4 MK-83 | 3 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{6CEB49FC-DED8-4DED-B053-E1F033FF72D3}",
					["num"] = 1,
				},
				[2] = {
					["CLSID"] = "{6CEB49FC-DED8-4DED-B053-E1F033FF72D3}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[4] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[5] = {
					["CLSID"] = "{BRU33_2X_MK-83}",
					["num"] = 2,
				},
				[6] = {
					["CLSID"] = "{BRU33_2X_MK-83}",
					["num"] = 8,
				},
				[7] = {
					["CLSID"] = "{C8E06185-7CD6-4C90-959F-044679E90751}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{C8E06185-7CD6-4C90-959F-044679E90751}",
					["num"] = 4,
				},
				[9] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
			},
			["tasks"] = {
				[1] = 32,
			},
		},
		[58] = {
			["name"] = "[MK-83 3]: 4 MK-83 | 2 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{6CEB49FC-DED8-4DED-B053-E1F033FF72D3}",
					["num"] = 1,
				},
				[2] = {
					["CLSID"] = "{6CEB49FC-DED8-4DED-B053-E1F033FF72D3}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[4] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[5] = {
					["CLSID"] = "{BRU33_2X_MK-83}",
					["num"] = 2,
				},
				[6] = {
					["CLSID"] = "{BRU33_2X_MK-83}",
					["num"] = 8,
				},
				[7] = {
					["CLSID"] = "{C8E06185-7CD6-4C90-959F-044679E90751}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{C8E06185-7CD6-4C90-959F-044679E90751}",
					["num"] = 4,
				},
			},
			["tasks"] = {
				[1] = 32,
			},
		},
		[59] = {
			["name"] = "[J-82 4]: 4 GBU-38 | TGP | 3 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[4] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[5] = {
					["CLSID"] = "{BRU55_2*GBU-38}",
					["num"] = 2,
				},
				[6] = {
					["CLSID"] = "{BRU55_2*GBU-38}",
					["num"] = 8,
				},
				[7] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
				[9] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
			},
			["tasks"] = {
				[1] = 32,
			},
		},
		[60] = {
			["name"] = "AIM-9X*2, AIM-120C*4, AIM-7MH*2, FUEL*1",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[3] = {
					["CLSID"] = "{AIM-7H}",
					["num"] = 4,
				},
				[4] = {
					["CLSID"] = "{AIM-7H}",
					["num"] = 6,
				},
				[5] = {
					["CLSID"] = "{LAU-115 - AIM-120C}",
					["num"] = 8,
				},
				[6] = {
					["CLSID"] = "{LAU-115 - AIM-120C}",
					["num"] = 7,
				},
				[7] = {
					["CLSID"] = "{LAU-115 - AIM-120C}",
					["num"] = 3,
				},
				[8] = {
					["CLSID"] = "{LAU-115 - AIM-120C}",
					["num"] = 2,
				},
				[9] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
			},
			["tasks"] = {
				[1] = 11,
			},
		},
		[61] = {
			["name"] = "[MK-82 1]: 4 MK-82 | 2 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{6CEB49FC-DED8-4DED-B053-E1F033FF72D3}",
					["num"] = 1,
				},
				[2] = {
					["CLSID"] = "{6CEB49FC-DED8-4DED-B053-E1F033FF72D3}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[4] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[5] = {
					["CLSID"] = "{BRU33_2X_MK-82}",
					["num"] = 2,
				},
				[6] = {
					["CLSID"] = "{BRU33_2X_MK-82}",
					["num"] = 8,
				},
				[7] = {
					["CLSID"] = "{C8E06185-7CD6-4C90-959F-044679E90751}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{C8E06185-7CD6-4C90-959F-044679E90751}",
					["num"] = 4,
				},
			},
			["tasks"] = {
				[1] = 32,
			},
		},
		[62] = {
			["name"] = "[J-84 BB 2]: 2 GBU-31(V)3/B | TGP | 3 Tanks | AAM",
			["pylons"] = {
				[1] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 1,
				},
				[2] = {
					["CLSID"] = "{5CE2FF2A-645A-4197-B48D-8720AC69394F}",
					["num"] = 9,
				},
				[3] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 3,
				},
				[4] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 7,
				},
				[5] = {
					["CLSID"] = "{GBU-31V3B}",
					["num"] = 2,
				},
				[6] = {
					["CLSID"] = "{GBU-31V3B}",
					["num"] = 8,
				},
				[7] = {
					["CLSID"] = "{40EF17B7-F508-45de-8566-6FFECC0C1AB8}",
					["num"] = 6,
				},
				[8] = {
					["CLSID"] = "{AAQ-28_LEFT}",
					["num"] = 4,
				},
				[9] = {
					["CLSID"] = "{FPU_8A_FUEL_TANK}",
					["num"] = 5,
				},
			},
			["tasks"] = {
				[1] = 32,
			},
		},
	},
	["unitType"] = "FA-18C_hornet",
}
return unitPayloads

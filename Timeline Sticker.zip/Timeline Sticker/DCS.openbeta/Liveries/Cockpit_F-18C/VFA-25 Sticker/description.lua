livery = 
{
    {"F-18C-mirror", 0 ,"mirrors",true};--mirrors texture replacement with runtime rendered one
	{"f18c_cpt01-console", 1, "f18c_cpt-tex01_nrm", true};
	{"f18c_cpt01-console-arg460", 1, "f18c_cpt-tex01_nrm", true};
	{"f18c_cpt01-console-arg466", 1, "f18c_cpt-tex01_nrm", true};
	{"f18c_cpt04-console-front-arg466", 0, "f18c_cpt-tex04", true};
	{"f18c_cpt04-instr", 0, "f18c_cpt-tex04", true};
	{"f18c_cpt04-console-front-arg466", 1, "f18c_cpt-tex04_nrm", true};
	{"f18c_cpt04-instr", 1, "f18c_cpt-tex04_nrm", true};
	{"f18c_cpt05-gray", 0, "f18c_cpt-tex05", false};
	{"f18c_cpt05-gray", 1, "f18c_cpt-tex05_nrm", false};
	{"f18c_cpt07-gray", 1, "f18c_cpt-tex07_nrm", true};
	{"f18c_cpt08-frame", 0, "f18c_cpt-tex08", true};
	{"f18c_cpt08-frame", 1, "f18c_cpt-tex08_nrm", true};
	{"f18c_cpt09-hud", 1, "f18c_cpt-tex09_nrm", true};
	{"f18c_cpt10-frame", 0, "f18c_cpt-tex10", true};
	{"f18c_cpt10-frame", 1, "f18c_cpt-tex10_nrm", true};
	{"f18c_cpt-wire", 0, "f18c_cpt-wire", true};
	
    
	{"f18c_cpt-displayglass", 0, "f18c_cpt-displayglass_refl", true};
	{"f18c_cpt-glass_full", 0, "f18c_cpt-glass_refl", true};
	{"f18c_cpt-hudl", 0, "f18c_cpt-glass_refl", true};
	--{"f18c_cpt-glass_full", ROUGHNESS_METALLIC , "f18c_cpt-glass_refl_RoughMet", false};
	--{"f18c_cpt-hudl", ROUGHNESS_METALLIC , "f18c_cpt-glass_refl_RoughMet", false};
	--{"f18c_cpt-glass_hud_edge", ROUGHNESS_METALLIC , "f18c_cpt-glass_hud_RoughMet", false};
	--
	
	
	{"f18c_cpt03-instr", ROUGHNESS_METALLIC , "f18c_cpt-tex03_RoughMet", true};
	{"f18c_cpt03-instr-arg466", ROUGHNESS_METALLIC , "f18c_cpt-tex03_RoughMet", true};
	{"f18c_cpt03-ifei-green-arg468", ROUGHNESS_METALLIC , "f18c_cpt-tex03_RoughMet", true};
	{"f18c_cpt03-ifei-red-arg468", ROUGHNESS_METALLIC , "f18c_cpt-tex03_RoughMet", true};
	
	{"f18c_cpt03-instr-arg460", ROUGHNESS_METALLIC ,"f18c_cpt-tex03_RoughMet",true};
	{"f18c_cpt04-console-front-arg466", ROUGHNESS_METALLIC , "f18c_cpt-tex04_RoughMet", true};
	{"f18c_cpt05-gray", ROUGHNESS_METALLIC , "f18c_cpt-tex05_RoughMet", false};
	{"f18c_cpt08-frame", ROUGHNESS_METALLIC , "f18c_cpt-tex08_RoughMet", true};
	{"f18c_cpt10-frame", ROUGHNESS_METALLIC , "f18c_cpt-tex10_RoughMet", true};

	




}
	-- COMPLETE LIST
    --{"f18c_cpt02-instr", 0, "f18c_cpt-tex02", true};
    --{"f18c_cpt02-instr", 1, "f18c_cpt-tex02_nrm", true};
    --{"f18c_cpt03-instr-arg460", 0, "f18c_cpt-tex03", true};
    --{"f18c_cpt03-instr-arg460", 1, "f18c_cpt-tex03_nrm", true};
    --{"f18c_cpt01-console", 0, "f18c_cpt-tex01", true};
    --{"f18c_cpt01-console", 1, "f18c_cpt-tex01_nrm", true};
    --{"f18c_cpt05-gray", 0, "f18c_cpt-tex05", true};
    --{"f18c_cpt05-gray", 1, "f18c_cpt-tex05_nrm", true};
    --{"f18c_cpt01-console-arg460", 0, "f18c_cpt-tex01", true};
    --{"f18c_cpt01-console-arg460", 1, "f18c_cpt-tex01_nrm", true};
    --{"f18c_cpt06-gray", 0, "f18c_cpt-tex06", true};
    --{"f18c_cpt06-gray", 1, "f18c_cpt-tex06_nrm", true};
    --{"f18c_cpt08-frame", 0, "f18c_cpt-tex08", true};
    --{"f18c_cpt08-frame", 1, "f18c_cpt-tex08_nrm", true};
    --{"f18c_cpt02-instr-arg460", 0, "f18c_cpt-tex02", true};
    --{"f18c_cpt02-instr-arg460", 1, "f18c_cpt-tex02_nrm", true};
    --{"f18c_cpt10-frame", 0, "f18c_cpt-tex10", true};
    --{"f18c_cpt10-frame", 1, "f18c_cpt-tex10_nrm", true};
    --{"f18c_cpt11-stick", 0, "f18c_cpt-tex11", true};
    --{"f18c_cpt11-stick", 1, "f18c_cpt-tex11_nrm", true};
    --{"f18c_cpt-brush2", 0, "f18c_cpt-brush", true};
    --{"f18c_cpt-brush2", 1, "f18c_cpt-brush_nrm", true};
    --{"f18c_cpt12-throttle", 0, "f18c_cpt-tex12", true};
    --{"f18c_cpt12-throttle", 1, "f18c_cpt-tex12_nrm", true};
    --{"f18c_cpt-wire", 0, "f18c_cpt-wire", true};
    --{"f18c_cpt-wire", 1, "f18c_cpt-wire_nrm", true};
    --{"f18c_cpt03-instr", 0, "f18c_cpt-tex03", true};
    --{"f18c_cpt03-instr", 1, "f18c_cpt-tex03_nrm", true};
    --{"f18c_cpt-brush3", 0, "f18c_cpt-brush", true};
    --{"f18c_cpt-brush3", 1, "f18c_cpt-brush_nrm", true};
    --{"f18c_cpt-brush1", 0, "f18c_cpt-brush", true};
    --{"f18c_cpt-brush1", 1, "f18c_cpt-brush_nrm", true};
    --{"f18c_naces2", 0, "f18c_cpt-naces2", true};
    --{"f18c_naces2", 1, "f18c_cpt-naces2_nrm", true};
    --{"f18c_cpt03-instr-arg466", 0, "f18c_cpt-tex03", true};
    --{"f18c_cpt03-instr-arg466", 1, "f18c_cpt-tex03_nrm", true};
    --{"f18c_cpt-light-arg521", 0, "f18c_cpt-lights", true};
    --{"f18c_cpt02-ifei-green-arg469", 0, "f18c_cpt-tex02", true};
    --{"f18c_cpt02-ifei-green-arg469", 1, "f18c_cpt-tex02_nrm", true};
    --{"f18c_cpt02-instr-arg466", 0, "f18c_cpt-tex02", true};
    --{"f18c_cpt02-instr-arg466", 1, "f18c_cpt-tex02_nrm", true};
    --{"f18c_cpt04-console-front-arg466", 0, "f18c_cpt-tex04", true};
    --{"f18c_cpt04-console-front-arg466", 1, "f18c_cpt-tex04_nrm", true};
    --{"f18c_cpt03-ifei-green-arg468", 0, "f18c_cpt-tex03", true};
    --{"f18c_cpt03-ifei-green-arg468", 1, "f18c_cpt-tex03_nrm", true};
    --{"f18c_cpt03-ifei-red-arg468", 0, "f18c_cpt-tex03", true};
    --{"f18c_cpt03-ifei-red-arg468", 1, "f18c_cpt-tex03_nrm", true};
    --{"f18c_cpt09-hud", 0, "f18c_cpt-tex09", true};
    --{"f18c_cpt09-hud", 1, "f18c_cpt-tex09_nrm", true};
    --{"f18c_cpt04-instr", 0, "f18c_cpt-tex04", true};
    --{"f18c_cpt04-instr", 1, "f18c_cpt-tex04_nrm", true};
    --{"f18c_cpt-glass_hud_edge", 0, "f18c_cpt-glass_hud", true};
    --{"f18c_cpt-light-arg522", 0, "f18c_cpt-lights", true};
    --{"f18c_cpt07-gray", 0, "f18c_cpt-tex07", true};
    --{"f18c_cpt07-gray", 1, "f18c_cpt-tex07_nrm", true};
    --{"f18c_cpt-light-arg523", 0, "f18c_cpt-lights", true};
    --{"f18c_cpt-displayglass", 0, "f18c_cpt-displayglass_refl", true};
    --{"f18c_cpt-displayglass", 14, "f18c_cpt-displayglass-dif", true};
    --{"f18c_cpt-glass_full", 0, "f18c_cpt-glass_refl", true};
    --{"f18c_cpt-glass_full", 1, "f18c_cpt-glass_nrm", true};
    --{"f18c_cpt-glass_full", 14, "f18c_cpt-glass_dif", true};
    --{"f18c1", 0, "f18c_1_dif", true};
    --{"f18c1", 1, "f18c_1_nm", true};
    --{"f18c1", 2, "f18c_1_dif_roughmet", true};
    --{"f18c_cpt-hudl", 0, "f18c_cpt-glass_refl", true};
    --{"f18c_cpt-hudl", 14, "f18c_cpt-glass_dif", true};
    --{"f18c_cpt_back", 0, "f18c-cpt_back", true};
    --{"f18c_cpt_back", 1, "f18c-cpt_back_nrm", true};
    --{"cockpit_f18c_2", 0, "f18c_cockpit_2_dif", true};
    --{"cockpit_f18c_2", 2, "f18c_cockpit_2_dif_roughmet", true};
    --{"f18c_cpt02-instr-arg467", 0, "f18c_cpt-tex02", true};
    --{"f18c_cpt02-instr-arg467", 1, "f18c_cpt-tex02_nrm", true};
    --{"f18c_naces1", 0, "f18c_cpt-naces1", true};
    --{"f18c_naces1", 1, "f18c_cpt-naces1_nrm", true};
    --{"f18c_cpt-hudlight-arg520", 0, "f18c_cpt-lights", true};
    --{"F-18C-mirror", 0, "a-10c_mirrors", true};
    --{"f18c_cpt-hudlight-arg499", 0, "f18c_cpt-lights", true};
    --{"f18c_cpt01-console-arg466", 0, "f18c_cpt-tex01", true};
    --{"f18c_cpt01-console-arg466", 1, "f18c_cpt-tex01_nrm", true};
    --{"f18c_cpt-rwr_mesh", 0, "f18-cpt_rwr", true};
    --{"f18c_cpt-rwr", 0, "f18-cpt_rwr", true};
    --{"f18c_cpt-light-arg520", 0, "f18c_cpt-lights", true};
    --{"pilot_F5_FP", 0, "pilot_f18_fp", true};
    --{"pilot_F5_FP", 1, "pilot_f18_fp_nm", true};
    --{"pilot_F5_FP", 2, "pilot_f18_fp_roughmet", true};
    --{"map", 0, "pilot_f18_fp_kneeboard", true};
    --{"f18c_cpt-belt", 0, "f18c_cpt-belt", true};
    --{"f18c_cpt-belt", 1, "f18c_cpt-belt_nrm", true};